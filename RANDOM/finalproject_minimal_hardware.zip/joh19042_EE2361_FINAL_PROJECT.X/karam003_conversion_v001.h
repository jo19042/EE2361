/* 
 * File:   karam003_conversion_v001.h
 * Author: nacob
 *
 * Created on April 2, 2021, 7:57 PM
 */

#ifndef KARAM033_CONVERSION_V001_H
#define	KARAM033_CONVERSION_V001_H

#ifdef	__cplusplus
extern "C" {
#endif
    void convertVal(float radius, float rpm, float rev);
#ifdef	__cplusplus
}
#endif

#endif	/* KARAM033_CONVERSION_V001_H */