#include "xc.h"
#include "joh19042_rotationsLib_v001.h"
#include "lixx5451_i2cLCD.h"

/*RPM will basically just be number of detections per minute. All I have to do
 is attach an input pin to an Input compare and interrupt everything something
 detected. I will then use a timer maybe every second that will calculate the 
 current rpm. I will have to scale this up so if I measure 5 detections in 1 
 second then */



//note: DC motors don't have RPM faster than 5000

//Number of rotations for this second
int rotations;
// the newRPM variable from the main function
extern unsigned long int newRPM;



/**
 * Initialization function to establish Timer5 and Input Compare for 
 */
void init_RPM(void){
    // Timer4 Configuration for IR sensing
    T5CON = 0;
    T5CONbits.TCKPS = 0b11; // 256 prescaler
    TMR5 = 0;
    PR5 = 62500 - 1;        // 1s; prescaler = 256 (16M cycles/256=62.5k)
    _T5IE = 1;              // enable interrupt
    _T5IF = 0;              // clear interrupt flag
    T5CONbits.TON = 1;      // turn on timer
    
    IC3CON = 0; // Turn off and reset internal state of IC1
    IC3CONbits.ICTMR = 0; // Use Timer 3 for capture source
    IC3CONbits.ICM = 0b010; // Turn on and capture every rising edge
    
    //IC3 Configuration for IR Sensing
    _IC3IF = 0; // Clear the IC1 interrupt status flag
    _IC3IE = 1; // Enable IC1 interrupts

    
}


/**
 * Timer4 interrupt. Will occur every second and update the rotations per minute
 * using the rotations during that second.
 */
void __attribute__((__interrupt__, __auto_psv__)) _T5Interrupt(void){    
    _T5IF = 0; // Reset timer4 interrupt flag
    newRPM = rotations * 60; // calculate rotations
    rotations = 0; // reset number of rotations for next second.
}


/**
 * Input Capture 3 Interrupt. Will occur every time the IR sensor detects,
 * increments rotations as this means there was a rotation.
 */
void __attribute__((__interrupt__, __auto_psv__)) _IC3Interrupt(void){
    _IC3IF = 0; // Reset interrupt flag or IC3
    rotations++; // increment number of rotations for the current second
}
