// Only the init_buttons function will be needed from this header file.

#ifndef LIXX5451_BUTTON_H
#define	LIXX5451_BUTTON_H

#include "xc.h"

#ifdef	__cplusplus
extern "C" {
#endif
    void init_buttons(int button1_RBx_bit, int button2_RBx_bit);    // for main
#ifdef	__cplusplus
}
#endif

#endif	/* LIXX5451_BUTTON_H */

