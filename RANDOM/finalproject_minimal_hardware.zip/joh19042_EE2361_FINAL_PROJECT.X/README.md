This is a working IR sensor library for the DAOKI IR Infrared Sensor. The library
was completed as a final project for EE 2361 Introduction to Microcontrollers in
Spring 2021 at the University of Minnesota Twin Cities.

There were 4 members of the group:
Jacob Johnson,
Nathan Gallagher,
Amanda Li, and
Javad Karamafrooz.

Jacob's main responsibilities included calculation of RPM using the IR sensor,
report documents, and keeping track of change in time for total distance calculations.

Nathan's main responsibilities included

Amanda's main responsibilities included configuration of the LCD display,
configuration of button for toggling between measurement modes and LCD reset, and
the main program loop.

Javad's main responsibilities included creating a maximum speed and notifying
the user through the LCD when that speed was reached, and converting from RPM
calculated by Jacob into different speed units and deistances.
